# CRM — Tailwind CSS v4

| Bestand | Waarheen |
|---|---|
| `constants.ts` | vervangt `crm/_lib/constants.ts` |
| `crm-board.tsx` | vervangt `crm/_components/crm-board.tsx` |
| `crm-stats.tsx` | vervangt `crm/_components/crm-stats.tsx` |
| `crm-bulk-bar.tsx` | nieuw: `crm/_components/crm-bulk-bar.tsx` |
| `delete-action.ts` | de `deleteCrmRecords`-functie erbij in `crm/_lib/actions.ts` |

`crm-shell.tsx`, `crm-table.tsx` en `crm-detail.tsx` heb ik niet meegeleverd —
daar zijn alleen gerichte ingrepen nodig, hieronder opgesomd.

## 1. Bedrag en winkans eruit

**`_lib/types.ts`** — haal `dealValue` en `expectedCloseDate` uit `CrmRecord`
en uit `CrmRecordPatch`. (Kolommen mogen in de DB blijven staan; ze worden
niet meer gelezen of geschreven.)

**`_lib/view.ts`** — `valueOf()` en `formatCurrency()` vervallen; verwijder
beide en hun imports.

**`crm-shell.tsx`**
- sorteersleutel `'value'` weg uit de `sorters` en uit `SORT_KEYS`
- in `placeholderRecord()`: `dealValue` en `expectedCloseDate` weg
- in `exportCsv()`: de kolommen `Dealwaarde` en `Verwachte sluitdatum` weg

**`crm-table.tsx`** — de kolom `Waarde` weg (header + cel), `SortKey` zonder
`'value'`, en de imports van `valueOf` / `formatCurrency` eruit.

**`crm-detail.tsx`** — de velden dealwaarde en verwachte sluitdatum weg uit
het formulier en uit de patch die wordt verstuurd.

## 2. Verwijderen uit CRM

Twee ingangen, beide via dezelfde `deleteCrmRecords`-actie:

- **Per lead** — het menu op de kaart (`crm-board.tsx`) en, als je wilt, een
  gelijk menu in de tabelrij.
- **Bulk** — de rode knop in `CrmBulkBar`.

In `crm-shell.tsx` erbij:

```tsx
const [deleteKeys, setDeleteKeys] = useState<string[] | null>(null)
const [deletePending, startDelete] = useTransition()

function confirmDelete() {
  const keys = deleteKeys ?? []
  startDelete(async () => {
    const res = await deleteCrmRecords(keys)
    if (!res.ok) { setError(res.error); return }
    // Record naar null: de lead blijft in de lijst, maar valt terug op de defaults.
    setEntries((prev) =>
      prev.map((e) => (keys.includes(e.key) ? { ...e, record: null } : e))
    )
    setSelection(new Set())
    setDeleteKeys(null)
  })
}
```

En onderaan de render:

```tsx
<CrmBulkBar
  selection={selection}
  labels={labels}
  onStage={handleBulkStage}
  onLabel={handleBulkLabel}
  onDelete={() => setDeleteKeys([...selection])}
  onClear={() => setSelection(new Set())}
/>

{deleteKeys && (
  <DeleteFromCrmDialog
    entries={entries.filter((e) => deleteKeys.includes(e.key))}
    pending={deletePending}
    onCancel={() => setDeleteKeys(null)}
    onConfirm={confirmDelete}
  />
)}
```

De bulkbalk zat eerst achter `view === 'table'`; die voorwaarde vervalt, want
het board heeft nu ook selectie. Geef `CrmBoard` daarvoor `selection` en
`onToggleSelect` mee (dezelfde handlers als de tabel al gebruikt).

## 3. Extra tokens

Naast de tokens uit de eerdere pagina's:

```css
:root {
  --brand-06: color-mix(in oklab, var(--brand-color) 6%, transparent);
  --c-cat-lost: #b91c1c;
}
.dark { --c-cat-lost: #f87171; }

@theme inline {
  --color-warn: var(--c-warn);
  --color-pos: var(--c-pos);
  --color-neg: var(--c-neg);
  --color-ink: var(--c-ink);
}
```

De zes fasekleuren komen uit dezelfde `--c-cat-*` set als de Lead inbox en
Campagne leads, dus de stippen kloppen over alle pagina's heen.

## Wat er visueel veranderd is

**Kolommen** zijn witte panelen met een haarlijn in plaats van grijze vlakken,
met een kleurstip, een teller en een verhoudingsstreepje dat de kolomgrootte
toont — dat streepje staat op de plek van het oude valutatotaal.

**Kaarten** — de zwarte avatarcirkel is weg; links zit nu het selectievakje
(verschijnt bij hover, blijft staan zodra er iets geselecteerd is), rechts een
menuknop. De volgende actie is een gekleurde regel: rood te laat, oranje
vandaag, grijs later. Labels zijn omlijnde chips met een stip in plaats van
gekleurde vlakken.

**Kaartmenu** — verankerd aan de kaart met `inset-x-1.5`, niet op een vaste
breedte. Een breder menu wordt door de scrollende kolom weggeknipt.

## Waarden

| Rol | Waarde |
|---|---|
| kolombreedte | 222px, gap 12px, bord scrollt horizontaal |
| kaart | radius 10px, padding 10px 11px |
| kolomkop | 12.5px / 600, teller 11px op `--c-track` |
| kaartnaam | 12.5px / 600 / −0.01em |
| bedrijf, actie | 11px / 10.5px |
| selectievakje | 14px, radius 4px |
| kerncijfer | 24px / 600 / −0.035em / tabular |
| bulkbalk | `--c-ink`, radius 11px, schaduw `0 10px 30px -12px` |
