'use server'

import { revalidatePath } from 'next/cache'
import { createClient } from '@/lib/supabase/server'
import { createAdminClient } from '@/lib/supabase/admin'
import type { ActionResult } from './types'

/**
 * Verwijdert alleen de CRM-laag (crm_records + bijbehorende activiteiten en
 * labelkoppelingen). De bron-lead in de lead-inbox blijft ongemoeid; zodra de
 * klant de lead opnieuw een fase geeft, ontstaat er een nieuw record.
 *
 * Voeg dit toe aan `crm/_lib/actions.ts`.
 */
export async function deleteCrmRecords(leadKeys: string[]): Promise<ActionResult<string[]>> {
  if (leadKeys.length === 0) return { ok: true, value: [] }

  const supabase = await createClient()
  const {
    data: { user },
  } = await supabase.auth.getUser()
  if (!user) return { ok: false, error: 'Niet ingelogd.' }

  const clientId = user.app_metadata?.client_id as string | undefined
  if (!clientId) return { ok: false, error: 'Geen klant gekoppeld aan dit account.' }

  const admin = createAdminClient()
  const keys = leadKeys.map((k) => k.toLowerCase())

  const { data, error } = await admin
    .from('crm_records')
    .delete()
    .eq('client_id', clientId)
    .in('lead_key', keys)
    .select('lead_key')

  if (error) {
    console.error('CRM delete error:', error)
    return { ok: false, error: 'Verwijderen is niet gelukt. Probeer het opnieuw.' }
  }

  revalidatePath('/dashboard/crm')
  return { ok: true, value: (data ?? []).map((r) => r.lead_key as string) }
}
