'use client'

import { useCallback, useRef, useState } from 'react'

/**
 * Bedrijfslogo, herleid uit het e-maildomein van het contact.
 *
 * Het logo is een verrijking bovenop de initialen-tegel, geen vervanging:
 * de <img> staat op opacity 0 en wordt alleen zichtbaar als er echt een logo
 * binnenkomt. Dat is nodig omdat de favicon-service HTTP 200 met een generieke
 * grijze globe (16px) teruggeeft voor domeinen die ze niet kent, en omdat de
 * service door adblockers en bedrijfsnetwerken geblokkeerd kan zijn. In al die
 * gevallen — en tijdens het laden — blijven de initialen staan.
 *
 * ⚠ Privacy: zie de README. Deze variant vraagt het logo per weergave op bij
 * een externe partij, met het domein van de prospect in de URL. Voor productie
 * hoort dat server-side gecachet te worden (`logoUrlFor` hieronder is het
 * enige punt dat je daarvoor hoeft aan te passen).
 */

export function domainOf(email: string | undefined | null): string {
  return (email?.split('@')[1] ?? '').toLowerCase()
}

export function logoInitials(value: string): string {
  return value
    .split(/[\s.]+/)
    .filter(Boolean)
    .map((w) => w[0])
    .slice(0, 2)
    .join('')
    .toUpperCase()
}

/** Eén plek om van bron te wisselen (Clearbit, Logo.dev, of je eigen cache). */
export function logoUrlFor(domain: string, size = 128): string | null {
  if (!domain) return null
  return `https://www.google.com/s2/favicons?domain=${encodeURIComponent(domain)}&sz=${size}`
  // Zelf gehost, aanbevolen voor productie:
  // return `/api/logo/${encodeURIComponent(domain)}`
}

interface Props {
  domain: string
  /** Waaruit de initialen worden afgeleid — meestal de bedrijfsnaam. */
  label: string
  /** Rendergrootte in px. 26 in de tabel, 38 in het detailpaneel. */
  size?: number
}

export function CompanyLogo({ domain, label, size = 26 }: Props) {
  const [shown, setShown] = useState(false)
  const ref = useRef<HTMLImageElement>(null)
  const src = logoUrlFor(domain)

  // Een echte favicon is groter dan de 16px placeholder die de service
  // teruggeeft voor onbekende domeinen.
  const reveal = useCallback(() => {
    const img = ref.current
    if (img && img.naturalWidth > 16) setShown(true)
  }, [])

  return (
    <span
      title={domain || undefined}
      style={{ width: size, height: size, fontSize: size < 32 ? 9.5 : 12 }}
      className="relative flex shrink-0 items-center justify-center overflow-hidden rounded-[7px] border border-line bg-panel font-semibold tracking-[0.02em] text-muted"
    >
      {logoInitials(label)}
      {src && (
        <img
          ref={ref}
          src={src}
          alt=""
          loading="lazy"
          onLoad={reveal}
          /* Ref-sweep voor plaatjes die al uit de cache kwamen voordat React
             de handler koppelde. */
          onError={() => setShown(false)}
          style={{ padding: size < 32 ? 3 : 5, opacity: shown ? 1 : 0 }}
          className={`absolute inset-0 h-full w-full object-contain ${
            shown ? 'bg-panel' : 'bg-transparent'
          }`}
        />
      )}
    </span>
  )
}
