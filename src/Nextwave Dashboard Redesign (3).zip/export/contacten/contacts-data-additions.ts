import { cache } from 'react'
import { createAdminClient } from '@/lib/supabase/admin'

/**
 * Aanvullingen op `lib/data/contacts-data.ts`.
 * De bestaande getContactsPage / getContactColumns blijven ongewijzigd.
 */

/**
 * Vulpercentage per kolom — voedt de kolomkiezer, zodat de klant ziet welke
 * velden de moeite waard zijn om te tonen. Gemeten over een steekproef; over
 * de volledige tabel is dit te duur voor een paginaweergave.
 */
export const getColumnFillRates = cache(async (
  clientId: string,
  sampleSize = 500
): Promise<Record<string, number>> => {
  const admin = createAdminClient()

  const { data, error } = await admin
    .from('contacts')
    .select('data')
    .eq('client_id', clientId)
    .limit(sampleSize)

  if (error || !data?.length) return {}

  const counts: Record<string, number> = {}
  for (const row of data as { data: Record<string, string> }[]) {
    for (const [key, value] of Object.entries(row.data ?? {})) {
      if (value != null && String(value).trim() !== '') counts[key] = (counts[key] ?? 0) + 1
    }
  }

  const rates: Record<string, number> = {}
  for (const [key, n] of Object.entries(counts)) {
    rates[key] = Math.round((n / data.length) * 100)
  }
  return rates
})

/**
 * Welke kolom-id's naam, e-mail en bedrijf bevatten. De vaste eerste kolom en
 * het logo hebben die nodig; kolomnamen verschillen per klant.
 */
export const resolveKeyColumns = (
  columns: { id: string; name: string }[]
): { nameColumnId: string; emailColumnId: string; companyColumnId?: string } => {
  const find = (re: RegExp) => columns.find((c) => re.test(c.name))?.id
  return {
    nameColumnId: find(/^(volledige )?naam|full ?name|contact/i) ?? columns[0]?.id ?? '',
    emailColumnId: find(/e-?mail/i) ?? columns[1]?.id ?? '',
    companyColumnId: find(/bedrijf|company|organisatie/i),
  }
}
