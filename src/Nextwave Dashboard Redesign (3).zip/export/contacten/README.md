# Contacten — Tailwind CSS v4

| Bestand | Waarheen |
|---|---|
| `company-logo.tsx` | nieuw: `contacten/_components/company-logo.tsx` |
| `contacts-table.tsx` | vervangt `contacten/_components/contacts-table.tsx` |
| `contact-detail.tsx` | vervangt `contacten/_components/contact-detail.tsx` |
| `contacts-data-additions.ts` | erbij in `lib/data/contacts-data.ts` |

## page.tsx

De pagina heeft nu volledige hoogte nodig (vaste toolbar, scrollende tabel,
paginering onderaan) en geeft een paar extra props door:

```tsx
const params = await searchParams
const page = Math.max(0, parseInt(params.page ?? '0', 10) || 0)
const pageSize = [50, 100, 250].includes(Number(params.per)) ? Number(params.per) : 50
const search = params.q ?? ''

const [{ contacts, total }, columns, fillRates, totalUnfiltered] = await Promise.all([
  getContactsPage(clientId, page, search, pageSize),
  getContactColumns(clientId),
  getColumnFillRates(clientId),
  getContactsCount(clientId),
])

const keys = resolveKeyColumns(columns)

return (
  <ContactsTable
    contacts={contacts.map((c) => ({ id: c.id, data: c.data }))}
    columns={columns}
    fillRates={fillRates}
    total={total}
    totalUnfiltered={totalUnfiltered}
    currentPage={page}
    pageSize={pageSize}
    search={search}
    {...keys}
  />
)
```

`getContactsPage` krijgt er een `pageSize`-parameter bij (nu een constante van
50) die als `p_limit` naar `search_contacts` gaat. De `<h1>` uit `page.tsx`
vervalt — die zit nu in de header van de tabelcomponent.

## ⚠ Logo's en privacy — lezen voor je dit live zet

`company-logo.tsx` haalt het logo op bij `google.com/s2/favicons`, met het
domein van de prospect in de URL. **Dat betekent dat bij elke paginaweergave de
domeinen van de contactenlijst van je klant naar Google gaan.** Voor een
Nederlands B2B-klantportaal is dat geen goede default.

Aanbevolen voor productie: haal het logo één keer op bij de import, sla het op
in je eigen storage, en zet die URL in het contactrecord. Of zet er een simpele
proxy met cache voor:

```ts
// app/api/logo/[domain]/route.ts — schets
export async function GET(req: Request, { params }: { params: { domain: string } }) {
  const cached = await getCachedLogo(params.domain)
  if (cached) return new Response(cached, { headers: { 'Cache-Control': 'public, max-age=2592000' } })
  const res = await fetch(`https://www.google.com/s2/favicons?domain=${params.domain}&sz=128`)
  const buf = await res.arrayBuffer()
  await cacheLogo(params.domain, buf)
  return new Response(buf, { headers: { 'Cache-Control': 'public, max-age=2592000' } })
}
```

Daarna alleen `logoUrlFor()` in `company-logo.tsx` omzetten naar
`/api/logo/${domain}` — de rest van de component blijft gelijk.

### Waarom het logo standaard onzichtbaar is

Twee valkuilen zitten al verwerkt:

1. De favicon-service geeft **HTTP 200 met een generieke grijze globe van
   16px** terug voor domeinen die ze niet kent. `onError` vuurt dus nooit; de
   controle is `naturalWidth > 16`.
2. De service wordt door adblockers en bedrijfsnetwerken geblokkeerd — precies
   het publiek van dit portaal.

Daarom staat de `<img>` op `opacity:0` met een transparante achtergrond en
wordt hij pas onthuld bij een bevestigd echt logo. Tijdens laden, bij een
onbekend domein en bij een geblokkeerde verbinding blijft de initialen-tegel
staan. Draai dat niet om naar "tonen tenzij het misgaat" — dan krijg je lege
witte vakjes.

## Extra tokens

Naast de tokens uit de eerdere pagina's:

```css
:root {
  --brand-04: color-mix(in oklab, var(--brand-color) 4%, transparent);
  --brand-05: color-mix(in oklab, var(--brand-color) 5%, transparent);
  --brand-07: color-mix(in oklab, var(--brand-color) 7%, transparent);
}
```

## Wat er veranderd is

**Kolomkiezer** — de tabel toonde hard de eerste vijf kolommen en de rest werd
"…", terwijl elke klant een eigen CSV-indeling heeft. Je kiest nu zelf welke
velden je ziet, met het vulpercentage per veld erbij. De keuze wordt in
`localStorage` onthouden.

**Vaste eerste kolom** met logo, naam en e-mail; de overige kolommen scrollen
er horizontaal onderlangs, zodat je bij brede bestanden weet naar wie je kijkt.

**Zoeken tijdens typen** (debounced, via de URL zodat je een zoekopdracht kunt
delen) met het aantal resultaten in het veld en `/` als sneltoets — in plaats
van een submit-knop met aparte wisknop.

**Detail is een vast paneel** naast de tabel in plaats van een overlay met
donkere achtergrond. Velden zijn gegroepeerd, elke regel is klikbaar om te
kopiëren, lege velden staan als gestippelde chips onderaan zodat je ziet wat
het bestand níét bevat. J/K om door de contacten te lopen.

**Toegevoegd**: selectie met bulkacties (exporteren, op DNC zetten),
dichtheidswissel, filter op bronbestand, en echte paginering met
paginanummers en instelbare paginagrootte.

## Waarden

| Rol | Waarde |
|---|---|
| vaste kolom | 282px, `border-r` haarlijn |
| datakolom | 168px |
| rijhoogte | 11px verticaal (ruim) / 7px (compact) |
| logotegel | 26px tabel / 38px detail, radius 7px |
| kolomkop | 10.5px / 600 / 0.09em / uppercase op `--c-track` |
| naam in rij | 12.5px / 600 / −0.01em, e-mail 11px |
| celtekst | 12px |
| detailpaneel | 356px, labelkolom 96px |
| radius paneel / knop | 12px / 8px |

Twee dingen die de tabel stukmaken als je ze weghaalt: `box-sizing: border-box`
(anders tellen de celpaddings bij de kolombreedte op) en `width: max-content`
op de tabelwrapper (anders stoppen de kopbalk en de rijlijnen bij horizontaal
scrollen halverwege de laatste kolom).
