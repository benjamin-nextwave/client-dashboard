'use client'

import { useCallback, useEffect, useMemo, useState } from 'react'
import { useRouter, useSearchParams } from 'next/navigation'
import { CompanyLogo, domainOf } from './company-logo'
import { ContactDetail } from './contact-detail'

export type ContactRow = { id: string; data: Record<string, string> }
export type ColumnDef = { id: string; name: string }

interface Props {
  contacts: ContactRow[]
  columns: ColumnDef[]
  /** Vulpercentage per kolom-id (0–100), uit getColumnFillRates. */
  fillRates?: Record<string, number>
  /** Bronbestanden om op te filteren, uit getContactSources. */
  sources?: { id: string; name: string }[]
  total: number
  totalUnfiltered: number
  currentPage: number
  pageSize: number
  search: string
  /** Kolom-id's die naam en e-mail bevatten — die staan in de vaste kolom. */
  nameColumnId: string
  emailColumnId: string
  companyColumnId?: string
}

const PAGE_SIZES = [50, 100, 250]
const DEFAULT_VISIBLE = 5

export function ContactsTable({
  contacts,
  columns,
  fillRates = {},
  sources = [],
  total,
  totalUnfiltered,
  currentPage,
  pageSize,
  search,
  nameColumnId,
  emailColumnId,
  companyColumnId,
}: Props) {
  const router = useRouter()
  const params = useSearchParams()

  const [query, setQuery] = useState(search)
  const [selection, setSelection] = useState<Set<string>>(new Set())
  const [openId, setOpenId] = useState<string | null>(null)
  const [dense, setDense] = useState(false)
  const [columnMenu, setColumnMenu] = useState(false)

  /* Kolommen die náást de vaste naam-kolom staan. */
  const dataColumns = useMemo(
    () => columns.filter((c) => c.id !== nameColumnId && c.id !== emailColumnId),
    [columns, nameColumnId, emailColumnId]
  )

  const [visible, setVisible] = useState<Set<string>>(
    () => new Set(dataColumns.slice(0, DEFAULT_VISIBLE).map((c) => c.id))
  )

  /* Kolomkeuze onthouden per klant — anders kiest iedereen elke sessie opnieuw. */
  useEffect(() => {
    const saved = localStorage.getItem('contacten:kolommen')
    if (saved) {
      try {
        const ids: string[] = JSON.parse(saved)
        const known = ids.filter((id) => dataColumns.some((c) => c.id === id))
        if (known.length) setVisible(new Set(known))
      } catch {
        /* genegeerd */
      }
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  function updateVisible(next: Set<string>) {
    setVisible(next)
    localStorage.setItem('contacten:kolommen', JSON.stringify([...next]))
  }

  const shownColumns = dataColumns.filter((c) => visible.has(c.id))

  /* Navigatie — zoeken debounced, res via de URL zodat delen werkt. */
  const navigate = useCallback(
    (patch: Record<string, string | number | null>) => {
      const next = new URLSearchParams(params.toString())
      for (const [k, v] of Object.entries(patch)) {
        if (v === null || v === '' || v === 0) next.delete(k)
        else next.set(k, String(v))
      }
      router.push(`/dashboard/contacten${next.toString() ? `?${next}` : ''}`)
    },
    [params, router]
  )

  useEffect(() => {
    if (query === search) return
    const timer = setTimeout(() => navigate({ q: query || null, page: null }), 300)
    return () => clearTimeout(timer)
  }, [query, search, navigate])

  /* Sneltoets: / focust het zoekveld. */
  useEffect(() => {
    function onKey(e: KeyboardEvent) {
      if (e.key === '/' && !(e.target instanceof HTMLInputElement)) {
        e.preventDefault()
        document.getElementById('contact-search')?.focus()
      }
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [])

  const totalPages = Math.max(1, Math.ceil(total / pageSize))
  const from = total === 0 ? 0 : currentPage * pageSize + 1
  const to = Math.min((currentPage + 1) * pageSize, total)
  const openContact = contacts.find((c) => c.id === openId) ?? null
  const openIndex = openContact ? contacts.indexOf(openContact) : -1
  const cellPad = dense ? 'py-[7px]' : 'py-[11px]'

  function toggle(id: string) {
    setSelection((cur) => {
      const next = new Set(cur)
      next.has(id) ? next.delete(id) : next.add(id)
      return next
    })
  }

  const pageWindow = Array.from({ length: Math.min(5, totalPages) }, (_, i) => {
    const start = Math.max(0, Math.min(currentPage - 2, totalPages - 5))
    return start + i
  })

  return (
    <div className="flex min-h-0 flex-1 flex-col bg-canvas font-sans text-fg">
      {/* Toolbar */}
      <div className="flex shrink-0 items-center gap-2.5 px-7 pt-[18px]">
        <label className="flex h-[34px] min-w-0 flex-1 items-center gap-[9px] rounded-control border border-line bg-panel px-[11px] focus-within:ring-2 focus-within:ring-brand">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.7} strokeLinecap="round" strokeLinejoin="round" className="h-[15px] w-[15px] shrink-0 text-faint" aria-hidden>
            <path d="m21 21-5.197-5.197m0 0A7.5 7.5 0 1 0 5.196 5.196a7.5 7.5 0 0 0 10.607 10.607Z" />
          </svg>
          <input
            id="contact-search"
            type="search"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Zoek op naam, bedrijf, e-mail of veldwaarde"
            className="w-full bg-transparent text-[12.5px] outline-none placeholder:text-faint [&::-webkit-search-cancel-button]:hidden"
          />
          {search ? (
            <>
              <span className="shrink-0 text-[11px] tabular-nums text-faint">
                {total.toLocaleString('nl-NL')} resultaten
              </span>
              <button type="button" onClick={() => setQuery('')} aria-label="Zoekopdracht wissen" className="shrink-0 text-faint">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2.2} strokeLinecap="round" className="h-[13px] w-[13px]">
                  <path d="M6 18 18 6M6 6l12 12" />
                </svg>
              </button>
            </>
          ) : (
            <kbd className="shrink-0 rounded border border-line px-[5px] py-px font-mono text-[10px] font-semibold text-faint">/</kbd>
          )}
        </label>

        {/* Kolomkiezer — de tabel toonde eerder hard de eerste vijf velden */}
        <div className="relative shrink-0">
          <button
            type="button"
            onClick={() => setColumnMenu((v) => !v)}
            className="flex h-[34px] items-center gap-2 whitespace-nowrap rounded-control border border-[color-mix(in_oklab,var(--color-brand)_30%,var(--color-line))] bg-[var(--brand-07)] px-3 text-[12.5px] font-medium"
          >
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.7} strokeLinecap="round" strokeLinejoin="round" className="h-[15px] w-[15px] text-muted" aria-hidden>
              <path d="M3.75 6A2.25 2.25 0 0 1 6 3.75h2.25A2.25 2.25 0 0 1 10.5 6v12a2.25 2.25 0 0 1-2.25 2.25H6A2.25 2.25 0 0 1 3.75 18V6ZM13.5 6a2.25 2.25 0 0 1 2.25-2.25H18A2.25 2.25 0 0 1 20.25 6v12A2.25 2.25 0 0 1 18 20.25h-2.25A2.25 2.25 0 0 1 13.5 18V6Z" />
            </svg>
            Kolommen
            <span className="inline-flex h-4 min-w-4 items-center justify-center rounded-full bg-brand px-[5px] text-[10.5px] font-semibold tabular-nums text-white">
              {shownColumns.length + 1}
            </span>
          </button>

          {columnMenu && (
            <div className="absolute right-0 top-10 z-30 w-[250px] rounded-[10px] border border-line bg-panel p-1.5 shadow-[0_14px_34px_-14px_rgba(0,0,0,0.34)]">
              <div className="px-2.5 pb-[7px] pt-2 text-[10px] font-semibold uppercase tracking-[0.14em] text-faint">
                Kolommen tonen
              </div>
              <div className="max-h-[260px] overflow-y-auto">
                {dataColumns.map((col) => {
                  const on = visible.has(col.id)
                  return (
                    <button
                      key={col.id}
                      type="button"
                      onClick={() => {
                        const next = new Set(visible)
                        on ? next.delete(col.id) : next.add(col.id)
                        updateVisible(next)
                      }}
                      className="flex w-full items-center gap-[9px] rounded-[7px] px-2.5 py-[7px] text-[12.5px] hover:bg-[var(--brand-08)]"
                    >
                      <span className={`flex h-3.5 w-3.5 shrink-0 items-center justify-center rounded border ${on ? 'border-brand bg-brand' : 'border-line'}`}>
                        {on && (
                          <svg viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth={3.6} strokeLinecap="round" strokeLinejoin="round" className="h-[9px] w-[9px]">
                            <path d="m4.5 12.75 6 6 9-13.5" />
                          </svg>
                        )}
                      </span>
                      <span className="flex-1 truncate text-left">{col.name}</span>
                      {fillRates[col.id] != null && (
                        <span className="shrink-0 text-[10px] tabular-nums text-faint">{fillRates[col.id]}%</span>
                      )}
                    </button>
                  )
                })}
              </div>
              <div className="mt-1 flex gap-3.5 border-t border-line px-2.5 pb-1 pt-[7px]">
                <button type="button" onClick={() => updateVisible(new Set(dataColumns.map((c) => c.id)))} className="text-[11.5px] font-medium text-brand">
                  Alles tonen
                </button>
                <button type="button" onClick={() => updateVisible(new Set(dataColumns.slice(0, DEFAULT_VISIBLE).map((c) => c.id)))} className="text-[11.5px] font-medium text-muted">
                  Standaard
                </button>
              </div>
            </div>
          )}
        </div>

        {sources.length > 1 && (
          <select
            defaultValue={params.get('bron') ?? ''}
            onChange={(e) => navigate({ bron: e.target.value || null, page: null })}
            className="h-[34px] shrink-0 rounded-control border border-line bg-panel px-3 text-[12.5px] font-medium outline-none"
          >
            <option value="">Alle bestanden</option>
            {sources.map((s) => (
              <option key={s.id} value={s.id}>{s.name}</option>
            ))}
          </select>
        )}

        {/* Dichtheid */}
        <div className="flex shrink-0 gap-0.5 rounded-[9px] border border-line bg-panel p-[3px]">
          {[
            { d: false, title: 'Ruime rijen', path: 'M3.75 5.25h16.5M3.75 12h16.5M3.75 18.75h16.5' },
            { d: true, title: 'Compacte rijen', path: 'M3.75 4.5h16.5M3.75 9h16.5M3.75 13.5h16.5M3.75 18h16.5' },
          ].map((opt) => (
            <button
              key={opt.title}
              type="button"
              title={opt.title}
              onClick={() => setDense(opt.d)}
              className={`flex h-[26px] w-[30px] items-center justify-center rounded-[7px] ${
                dense === opt.d ? 'bg-brand text-white' : 'text-faint hover:bg-[var(--brand-08)]'
              }`}
            >
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.9} strokeLinecap="round" className="h-[15px] w-[15px]">
                <path d={opt.path} />
              </svg>
            </button>
          ))}
        </div>
      </div>

      {/* Tabel + detail */}
      <div className="flex min-h-0 flex-1 gap-4 overflow-hidden px-7 pb-[22px] pt-3.5">
        <section className="flex min-w-0 flex-1 flex-col overflow-hidden rounded-panel border border-line bg-panel">
          <div className="min-h-0 flex-1 overflow-auto">
            {/* width:max-content zodat de kopbalk en de rijlijnen doorlopen
                tot de laatste kolom bij horizontaal scrollen. */}
            <div className="w-max min-w-full">
              <div className="sticky top-0 z-[3] flex items-center border-b border-line bg-track">
                <div className="sticky left-0 z-[2] flex w-[282px] shrink-0 items-center gap-2.5 border-r border-line bg-track px-3.5 py-[9px] text-[10.5px] font-semibold uppercase tracking-[0.09em] text-faint">
                  <span className="h-3.5 w-3.5 shrink-0 rounded border border-line" />
                  Naam
                </div>
                {shownColumns.map((col) => (
                  <div key={col.id} className="w-[168px] shrink-0 whitespace-nowrap px-3.5 py-[9px] text-[10.5px] font-semibold uppercase tracking-[0.09em] text-faint">
                    {col.name}
                  </div>
                ))}
              </div>

              {contacts.map((contact) => {
                const selected = selection.has(contact.id)
                const isOpen = openId === contact.id
                const name = contact.data[nameColumnId] || '—'
                const email = contact.data[emailColumnId] || ''
                const company = companyColumnId ? contact.data[companyColumnId] : ''
                const bg = isOpen
                  ? 'bg-[var(--brand-07)]'
                  : selected
                    ? 'bg-[var(--brand-04)]'
                    : 'bg-panel'

                return (
                  <div
                    key={contact.id}
                    onClick={() => setOpenId(contact.id)}
                    className="flex cursor-pointer items-stretch border-b border-line"
                  >
                    <div
                      className={`sticky left-0 z-[1] flex w-[282px] shrink-0 items-center gap-2.5 border-r border-line px-3.5 ${cellPad} ${bg} ${
                        isOpen ? 'shadow-[inset_2px_0_0_var(--color-brand)]' : ''
                      }`}
                    >
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation()
                          toggle(contact.id)
                        }}
                        aria-label={`Selecteer ${name}`}
                        className={`flex h-3.5 w-3.5 shrink-0 items-center justify-center rounded border ${
                          selected ? 'border-brand bg-brand' : 'border-line'
                        }`}
                      >
                        {selected && (
                          <svg viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth={3.6} strokeLinecap="round" strokeLinejoin="round" className="h-[9px] w-[9px]">
                            <path d="m4.5 12.75 6 6 9-13.5" />
                          </svg>
                        )}
                      </button>

                      <CompanyLogo domain={domainOf(email)} label={company || name} />

                      <div className="min-w-0 flex-1">
                        <div className="truncate text-[12.5px] font-semibold tracking-[-0.01em]">{name}</div>
                        {email && <div className="mt-0.5 truncate text-[11px] text-faint">{email}</div>}
                      </div>
                    </div>

                    {shownColumns.map((col) => {
                      const v = contact.data[col.id]
                      return (
                        <div
                          key={col.id}
                          className={`flex w-[168px] shrink-0 items-center overflow-hidden text-ellipsis whitespace-nowrap px-3.5 text-xs ${cellPad} ${bg} ${
                            v ? 'text-muted' : 'text-faint'
                          }`}
                        >
                          {v || '—'}
                        </div>
                      )
                    })}
                  </div>
                )
              })}

              {contacts.length === 0 && (
                <div className="px-6 py-12 text-center">
                  <h3 className="text-sm font-semibold">Geen contacten gevonden</h3>
                  <p className="mt-1 text-[12.5px] text-muted">
                    {search ? 'Pas je zoekopdracht aan.' : 'Contacten verschijnen hier zodra ze zijn geïmporteerd.'}
                  </p>
                </div>
              )}
            </div>
          </div>

          {/* Paginering */}
          <div className="flex shrink-0 items-center gap-3.5 border-t border-line px-4 py-2.5">
            <span className="text-xs tabular-nums text-muted">
              {from.toLocaleString('nl-NL')}–{to.toLocaleString('nl-NL')} van {total.toLocaleString('nl-NL')}
            </span>
            <div className="flex items-center gap-[7px]">
              <span className="text-xs text-faint">Per pagina</span>
              <div className="flex gap-0.5 rounded-[7px] border border-line p-0.5">
                {PAGE_SIZES.map((size) => (
                  <button
                    key={size}
                    type="button"
                    onClick={() => navigate({ per: size === 50 ? null : size, page: null })}
                    className={`rounded-[5px] px-[9px] py-[3px] text-[11.5px] tabular-nums ${
                      pageSize === size ? 'bg-brand font-semibold text-white' : 'font-medium text-muted'
                    }`}
                  >
                    {size}
                  </button>
                ))}
              </div>
            </div>
            <span className="flex-1" />
            <div className="flex items-center gap-[3px]">
              <button
                type="button"
                onClick={() => navigate({ page: currentPage - 1 || null })}
                disabled={currentPage === 0}
                aria-label="Vorige pagina"
                className="flex h-7 w-7 items-center justify-center rounded-[7px] border border-line bg-panel text-faint disabled:opacity-40"
              >
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" className="h-3.5 w-3.5">
                  <path d="M15.75 19.5 8.25 12l7.5-7.5" />
                </svg>
              </button>
              {pageWindow.map((p) => (
                <button
                  key={p}
                  type="button"
                  onClick={() => navigate({ page: p || null })}
                  className={`h-7 min-w-7 rounded-[7px] border px-2 text-xs tabular-nums ${
                    p === currentPage
                      ? 'border-brand bg-[var(--brand-10)] font-semibold text-brand'
                      : 'border-line bg-panel font-medium text-muted'
                  }`}
                >
                  {p + 1}
                </button>
              ))}
              <button
                type="button"
                onClick={() => navigate({ page: currentPage + 1 })}
                disabled={currentPage >= totalPages - 1}
                aria-label="Volgende pagina"
                className="flex h-7 w-7 items-center justify-center rounded-[7px] border border-line bg-panel text-faint disabled:opacity-40"
              >
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" className="h-3.5 w-3.5">
                  <path d="m8.25 4.5 7.5 7.5-7.5 7.5" />
                </svg>
              </button>
            </div>
          </div>
        </section>

        {openContact && (
          <ContactDetail
            contact={openContact}
            columns={columns}
            nameColumnId={nameColumnId}
            emailColumnId={emailColumnId}
            companyColumnId={companyColumnId}
            onPrev={() => setOpenId(contacts[Math.max(openIndex - 1, 0)]?.id ?? null)}
            onNext={() => setOpenId(contacts[Math.min(openIndex + 1, contacts.length - 1)]?.id ?? null)}
            onClose={() => setOpenId(null)}
          />
        )}
      </div>

      {/* Bulkbalk */}
      {selection.size > 0 && (
        <div className="mx-7 mb-[22px] flex shrink-0 items-center gap-2.5 rounded-[11px] bg-ink px-3.5 py-2.5 text-white shadow-[0_10px_30px_-12px_rgba(0,0,0,0.4)]">
          <span className="inline-flex h-[22px] shrink-0 items-center rounded-md bg-white/[0.14] px-[7px] text-[11px] font-bold tabular-nums">
            {selection.size}
          </span>
          <span className="shrink-0 text-[12.5px] font-medium">geselecteerd</span>
          {selection.size < total && (
            <button type="button" className="shrink-0 whitespace-nowrap text-xs font-medium text-white/65">
              Alle {total.toLocaleString('nl-NL')} selecteren
            </button>
          )}
          <div className="h-[18px] w-px shrink-0 bg-white/[0.16]" />
          <button type="button" className="flex h-7 shrink-0 items-center gap-[7px] whitespace-nowrap rounded-[7px] border border-white/[0.18] bg-white/[0.08] px-[11px] text-xs font-medium">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round" className="h-[13px] w-[13px]">
              <path d="M3 16.5v2.25A2.25 2.25 0 0 0 5.25 21h13.5A2.25 2.25 0 0 0 21 18.75V16.5M16.5 12 12 16.5m0 0L7.5 12m4.5 4.5V3" />
            </svg>
            Exporteren
          </button>
          <button type="button" className="flex h-7 shrink-0 items-center gap-[7px] whitespace-nowrap rounded-[7px] border border-[color-mix(in_oklab,var(--color-warn)_55%,transparent)] bg-[color-mix(in_oklab,var(--color-warn)_22%,transparent)] px-[11px] text-xs font-semibold">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.9} strokeLinecap="round" strokeLinejoin="round" className="h-[13px] w-[13px]">
              <path d="M9 12.75 11.25 15 15 9.75m-3-7.036A11.959 11.959 0 0 1 3.598 6 11.99 11.99 0 0 0 3 9.749c0 5.592 3.824 10.29 9 11.623 5.176-1.332 9-6.03 9-11.622 0-1.31-.21-2.571-.598-3.751h-.152c-3.196 0-6.1-1.248-8.25-3.285Z" />
            </svg>
            Op DNC zetten
          </button>
          <span className="flex-1" />
          <button type="button" onClick={() => setSelection(new Set())} className="shrink-0 whitespace-nowrap text-xs font-medium text-white/60">
            Selectie wissen
          </button>
        </div>
      )}
    </div>
  )
}
